criaCartao( //cria o cartao 
    'Programação', //tópico da pergunta
    'O que é Python?', //pergunta
    'O Python é uma linguagem de programação' //resposta
)

criaCartao(//cria o cartao 
    'Geografia', //tópico da pergunta
    'Qual a capital da França?', //pergunta
    'A capital da França é Paris' //resposta
)

criaCartao( //cria o cartao 
    'Programação', //tópico da pergunta
    'O que é uma função?', //pergunta
    'Uma função é um bloco de código que executa alguma tarefa' //resposta
)

criaCartao( //cria o cartao 
    'Lingua inglesa', //tópico da pergunta
    'Como se diz oi em Inglês?', //pergunta
    'Oi em ingles é HI (RAI)' //resposta
)
criaCartao( //cria o cartao 
    'Programação', //tópico da pergunta
    'O que é Python?', //pergunta
    'O Python é uma linguagem de programação' //resposta
)

criaCartao(//cria o cartao 
    'Geografia', //tópico da pergunta
    'Qual a capital da França?', //pergunta
    'A capital da França é Paris' //resposta
)

criaCartao( //cria o cartao 
    'Programação', //tópico da pergunta
    'O que é uma função?', //pergunta
    'Uma função é um bloco de código que executa alguma tarefa' //resposta
)

criaCartao( //cria o cartao 
    'Lingua inglesa', //tópico da pergunta
    'Como se diz oi em Inglês?', //pergunta
    'Oi em ingles é HI (RAI)' //resposta
)